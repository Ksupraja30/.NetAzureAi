﻿using Mscc.GenerativeAI;

string apiKey = "AQ.Ab8RN6KBkO2khY-VEYqKzCLqYA8OHYBWG8JoTSbpFI9B-ARX9w";
var googleAI = new GoogleAI(apiKey);
var model = googleAI.GenerativeModel(model: "gemini-3.6-flash");

Console.Write("Ask a question: ");
string? question = Console.ReadLine();
var response = await model.GenerateContent(question ?? "");
Console.WriteLine(response.Text);

/*
1. Imports the Gemini AI library required to interact with Google Gemini services.

2. Stores the API key used for authentication with Gemini AI.
3. Creates a GoogleAI object to interact with Google's Gemini service.
4. Selects the "gemini-3.6-flash" model to process user requests and generate responses.

5. Displays a prompt to the user and reads the input from the console.
6. Stores the user question in the question variable.
    Sends the user's question to the Gemini AI model.
7. The await keyword waits asynchronously for the AI response.
    The null-coalescing operator (?? "") ensures that a null value is not passed to the model.
8. GenerateContent() processes the prompt and returns the AI-generated response.
9. Displays the generated response on the console screen.
*/